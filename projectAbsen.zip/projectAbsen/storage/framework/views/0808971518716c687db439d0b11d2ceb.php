<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h1>FORM EDIT HARI</h1>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('admin.updateHari', $hari->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="day" class="form-label">Hari: </label>
                    <input type="text" class="form-control" id="day" name="nama" value="<?php echo e($hari->nama); ?>">
                </div>
                <button type="submit" class="btn2">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectAbsen\resources\views/admin/hari/editHari.blade.php ENDPATH**/ ?>