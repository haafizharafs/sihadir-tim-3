<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h1>FORM EDIT DOSEN</h1>
        </div>

        <div class="card-body">
        <form action="<?php echo e(route('admin.updateDosen', $user->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="namaDosen" class="form-label">Nama: </label>
                <input type="text" class="form-control" id="namaDosen" name="nama" value="<?php echo e($user->dosen->nama); ?>">
            </div>
            <div class="mb-3">
                <label for="nip" class="form-label">NIP: </label>
                <input type="text" class="form-control" id="nip" name="nip" value="<?php echo e($user->name); ?>">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password: </label>
                <input type="password" class="form-control" id="password" name="password">
                <small>*kosongkan jika tidak ingin mengubah password</small>
            </div>
            <div class="mb-3">
                <label for="">Jenis Kelamin</label>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="jenisKelamin" id="laki" value="L" <?php if($user->dosen->jenis_kelamin == 'L'): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="laki">
                                Pria
                            </label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="jenisKelamin" id="perempuan" value="P" <?php if($user->dosen->jenis_kelamin == 'P'): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="perempuan">
                                Wanita
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn2">Submit</button>
        </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectAbsen\resources\views/admin/dosen/editDosen.blade.php ENDPATH**/ ?>