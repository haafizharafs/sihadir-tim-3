<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h1>FORM EDIT MATA KULIAH</h1>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('admin.updateMataKuliah', $data['mataKuliah']->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="matkul" class="form-label">Nama Mata Kuliah: </label>
                    <input type="text" class="form-control" id="matkul" name="nama" value="<?php echo e($data['mataKuliah']->nama); ?>">
                </div>
                
                <button type="submit" class="btn2">Submit</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectAbsen\resources\views/admin/matakuliah/editMataKuliah.blade.php ENDPATH**/ ?>