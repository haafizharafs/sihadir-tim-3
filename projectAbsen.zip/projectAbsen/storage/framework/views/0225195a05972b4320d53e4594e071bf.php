<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h1>FORM EDIT MAHASISWA</h1>
        </div>

        <div class="card-body">
        <form action="<?php echo e(route('admin.updateMahasiswa', $user['user']->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="namaMahasiswa" class="form-label">Nama: </label>
                <input type="text" class="form-control" id="namaMahasiswa" name="nama" value="<?php echo e($user['user']->mahasiswa->nama); ?>">
            </div>

            <div class="mb-3">
                <div class="form-group">
                    <label for="kelas">Kelas</label>
                    <select name="kelas" id="kelas" class="custom-select">
                        <option value="">Pilih</option>
                        <?php $__currentLoopData = $user['kelas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kelas->id); ?>" class="form-control" <?php if($user['user']->mahasiswa->kelas_id == $kelas->id): ?> selected <?php endif; ?>><?php echo e($kelas->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="mb-3">
                <div class="form-group">
                    <label for="semester">Semester</label>
                    <select name="semester" id="semester" class="custom-select">
                        <option value="">Pilih</option>
                        <?php $__currentLoopData = $user['semester']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semester): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($semester->id); ?>" class="form-control" <?php if($user['user']->mahasiswa->semester_id == $semester->id): ?> selected <?php endif; ?>><?php echo e($semester->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="mb-3">
                <label for="nim" class="form-label">NIM: </label>
                <input type="text" class="form-control" id="nim" name="nim" value="<?php echo e($user['user']->name); ?>">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password: </label>
                <input type="password" class="form-control" id="password" name="password">
                <small>*kosongkan jika tidak ingin mengubah password</small>
            </div>
            <div class="mb-3">
                <label for="">Jenis Kelamin</label>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="jenisKelamin" id="laki" value="L" <?php if($user['user']->mahasiswa->jenis_kelamin == 'L'): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="laki">
                                Pria
                            </label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="jenisKelamin" id="perempuan" value="P" <?php if($user['user']->mahasiswa->jenis_kelamin == 'P'): ?> checked <?php endif; ?>>
                            <label class="form-check-label" for="perempuan">
                                Wanita
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn2">Submit</button>
        </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\projectAbsen\resources\views/admin/mahasiswa/editMahasiswa.blade.php ENDPATH**/ ?>