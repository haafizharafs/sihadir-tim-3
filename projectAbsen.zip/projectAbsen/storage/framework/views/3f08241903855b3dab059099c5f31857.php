<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css" />
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>/css/style.css" />
    <title>SiHadir</title>
    <link rel="shortcut icon" href="<?php echo e(asset('/')); ?>/images/sihadir.png">
</head>

<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="bg-side" id="sidebar-wrapper">
            <div class="sidebar-heading text-center py-4 primary-text fs-4 fw-bold text-uppercase border-bottom">
                <img src="<?php echo e(asset('/')); ?>/images/sihadir2.png" alt="" width="45" height="50"> SiHadir

            </div>
            <div class="list-group list-group-flush my-3">

                <?php if(auth()->guard()->guest()): ?>
                    <h1>Silahkan Login Terlebih Dahulu!</h1>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    <?php if (app('laratrust')->hasRole('admin')) : ?>
                        <a href="<?php echo e(url('/admin/dashboard')); ?>"
                            class="list-group-item list-group-item-action bg-transparent second-text active"><i
                                class="fas fa-home me-3"></i>Dashboard</a>
                        <a href="<?php echo e(url('/admin/pilih')); ?>"
                            class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                                class="fas fa-user-plus me-3"></i>Buat Akun</a>
                        <button class="list-group-item list-group-item-action bg-transparent second-text fw-bold d-block"
                            onclick="myAccFunc()"><i class="fas fa-file-alt me-3"></i>
                            Jadwal <i class=" fa fa-caret-down"></i>
                        </button>
                        <div id="demoAcc" class=" d-none   ">
                            <a href="#" class=" d-flex flex-column w3-bar-item w3-button text-white">Jadwal</a>
                            <a href="<?php echo e(url('/admin/mata-kuliah')); ?>"
                                class=" d-flex flex-column w3-bar-item w3-button text-white">Mata Kuliah</a>
                            <a href="<?php echo e(url('/admin/kelas')); ?>"
                                class="d-flex flex-column w3-bar-item w3-button text-white">Kelas</a>
                            <a href="<?php echo e(url('/admin/semester')); ?>"
                                class="d-flex flex-column w3-bar-item w3-button text-white">Semester</a>
                            <a href="<?php echo e(url('/admin/hari')); ?>"
                                class="d-flex flex-column w3-bar-item w3-button text-white">Hari</a>
                            <a href="<?php echo e(url('/admin/jam')); ?>"
                                class="d-flex flex-column w3-bar-item w3-button text-white">Jam</a>
                            <a href="<?php echo e(url('/admin/ruang')); ?>"
                                class="d-flex flex-column w3-bar-item w3-button text-white">Ruang</a>
                        </div>
                        <a href="<?php echo e(url('/admin/rekap')); ?>"
                            class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                                class="fas fa-calendar-alt me-3"></i> Data Rekap</a>
                    <?php endif; // app('laratrust')->hasRole ?>

                    <?php if (app('laratrust')->hasRole('dosen')) : ?>
                        <a href="<?php echo e(url('/dosen/dashboard')); ?>"
                            class="list-group-item list-group-item-action bg-transparent second-text active"><i
                                class="fas fa-home me-3"></i>Dashboard</a>
                        <a href="<?php echo e(url('/dosen/verifikasi')); ?>"
                            class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                                class="fas fa-check-circle me-3"></i>Verifikasi</a>
                        <a href="<?php echo e(url('/dosen/jadwal')); ?>"
                            class="list-group-item list-group-item-action bg-transparent second-text fw-bold d-block"><i
                                class="fas fa-file-alt me-3"></i>Jadwal</a>
                        <a href="<?php echo e(url('/dosen/rekap')); ?>"
                            class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                                class="fas fa-calendar-alt me-3"></i> Data Rekap</a>
                    <?php endif; // app('laratrust')->hasRole ?>

                    <?php if (app('laratrust')->hasRole('mahasiswa')) : ?>
                        <a href="<?php echo e(url('/mahasiswa/dashboard')); ?>"
                            class="list-group-item list-group-item-action bg-transparent second-text active"><i
                                class="fas fa-home me-3"></i>Dashboard</a>
                        <a href="<?php echo e(url('/mahasiswa/presensi')); ?>"
                            class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                                class="fas fa-list-alt me-3"></i>Presensi</a>
                        <a href="<?php echo e(url('/mahasiswa/jadwal')); ?>"
                            class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                                class="fas fa-file-alt me-3"></i> Jadwal</a>
                        <a href="<?php echo e(url('/mahasiswa/rekap')); ?>"
                            class="list-group-item list-group-item-action bg-transparent second-text fw-bold"><i
                                class="fas fa-calendar-alt me-3"></i> Data Rekap</a>
                    <?php endif; // app('laratrust')->hasRole ?>

                    <!--form untuk logout-->
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                    </form>
                    <!--tombol logout yang mengakses form logout-->
                    <a href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                        class="list-group-item list-group-item-action bg-transparent text-danger fw-bold"><i
                            class="fas fa-power-off me-2"></i>Logout</a>
                <?php endif; ?>

            </div>
        </div>



        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->

        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-transparent py-4 px-4">
                <div class="d-flex align-items-center">
                    <i class="fas fa-align-left primary-text fs-4 me-3" id="menu-toggle"></i>
                    <?php if (app('laratrust')->hasRole('admin')) : ?>
                        <h2 class="fs-2 m-0">Dashboard Admin</h2>
                    <?php endif; // app('laratrust')->hasRole ?>

                    <?php if (app('laratrust')->hasRole('dosen')) : ?>
                        <h2 class="fs-2 m-0">Dashboard Dosen</h2>
                    <?php endif; // app('laratrust')->hasRole ?>

                    <?php if (app('laratrust')->hasRole('mahasiswa')) : ?>
                        <h2 class="fs-2 m-0">Dashboard Mahasiswa</h2>
                    <?php endif; // app('laratrust')->hasRole ?>

                </div>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle second-text fw-bold" href="#"
                                id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php if(auth()->guard()->guest()): ?>
                                    <i class="fas fa-user me-2"></i>Belum Login
                                <?php endif; ?>

                                <?php if(auth()->guard()->check()): ?>
                                    <?php if (app('laratrust')->hasRole('admin')) : ?>
                                        <i class="fas fa-user me-2"></i>&nbsp &nbsp &nbsp &nbsp &nbsp<?php echo e(Auth::user()->name); ?>

                                    <?php endif; // app('laratrust')->hasRole ?>

                                    <?php if (app('laratrust')->hasRole('dosen')) : ?>
                                        <i class="fas fa-user me-2"></i>&nbsp &nbsp &nbsp &nbsp
                                        &nbsp<?php echo e(Auth::user()->dosen->nama); ?>

                                    <?php endif; // app('laratrust')->hasRole ?>

                                    <?php if (app('laratrust')->hasRole('mahasiswa')) : ?>
                                        <i class="fas fa-user me-2"></i>&nbsp<?php echo e(Auth::user()->mahasiswa->nama); ?>

                                    <?php endif; // app('laratrust')->hasRole ?>
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Profile</a></li>
                                <li><a class="dropdown-item" href="#">Logout</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </nav>

            <section>
                <?php echo $__env->yieldContent('content'); ?>

            </section>



        </div>

    </div>

    <!-- /#page-content-wrapper -->



    <script src="<?php echo e(asset('/')); ?>/js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script> -->
    <script>
        var el = document.getElementById("wrapper");
        var toggleButton = document.getElementById("menu-toggle");

        toggleButton.onclick = function() {
            el.classList.toggle("toggled");
        };
    </script>

    
    <script>
        function myAccFunc() {
            var x = document.getElementById("demoAcc");
            if (x.className.indexOf("w3-show") == -1) {
                x.className += " w3-show";
                x.previousElementSibling.className += " w3-green";
            } else {
                x.className = x.className.replace(" w3-show", "");
                x.previousElementSibling.className =
                    x.previousElementSibling.className.replace(" w3-green", "");
            }
        }

        function myDropFunc() {
            var x = document.getElementById("demoDrop");
            if (x.className.indexOf("w3-show") == -1) {
                x.className += " w3-show";
                x.previousElementSibling.className += " w3-green";
            } else {
                x.className = x.className.replace(" w3-show", "");
                x.previousElementSibling.className =
                    x.previousElementSibling.className.replace(" w3-green", "");
            }
        }
    </script>

</body>

</html>
<?php /**PATH C:\laragon\www\projectAbsen\resources\views/layouts/app.blade.php ENDPATH**/ ?>